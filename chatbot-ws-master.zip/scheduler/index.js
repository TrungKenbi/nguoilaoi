'use strict';

let matchUsers = require('./match-users');

matchUsers();