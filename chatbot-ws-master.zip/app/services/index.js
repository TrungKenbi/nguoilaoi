'use strict';

module.exports = {
    webhook: require('./webhook'),
    db: require('./database'),
    matchUser: require('./match-user'),
    msgSender: require('./message-sender')
};