'use strict';

module.exports = {
    fbHook : require('./fb/webhook')
};