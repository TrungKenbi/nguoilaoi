'use strict';

module.exports = {
    ResponseJSON: require('./response'),
    config: require('./config')
};